﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests
{
    [TestClass]
    public class ConsoleKeyConverterTests
    {
        [TestMethod]
        public void TryParseChar_CanParseLowerCase()
        {
            ConsoleKey consoleKey;
            bool result = ConsoleKeyConverter.TryParseChar('a', out consoleKey);

            Assert.IsTrue(result);
            Assert.AreEqual(ConsoleKey.A, consoleKey);
        }

        [TestMethod]
        public void TryParseChar_CanParseUpperCase()
        {
            ConsoleKey consoleKey;
            bool result = ConsoleKeyConverter.TryParseChar('A', out consoleKey);

            Assert.IsTrue(result);
            Assert.AreEqual(ConsoleKey.A, consoleKey);
        }

        [TestMethod]
        public void ConvertConsoleKey_CanConvert()
        {
            Assert.AreEqual('A', ConsoleKeyConverter.ConvertConsoleKey(ConsoleKey.A));
        }
    }
}
