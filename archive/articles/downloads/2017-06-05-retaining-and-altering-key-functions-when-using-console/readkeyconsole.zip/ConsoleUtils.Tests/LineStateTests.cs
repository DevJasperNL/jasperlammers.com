﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests
{
    [TestClass]
    public class LineStateTests
    {
        [TestMethod]
        public void LineState_Constructed()
        {
            const string line = "Test";
            const int cursorPosition = 2;

            var result = new LineState(line, cursorPosition);

            Assert.AreEqual(line, result.Line);
            Assert.AreEqual(cursorPosition, result.CursorPosition);
        }

        [TestMethod]
        public void LineState_NullLine()
        {
            const int cursorPosition = 2;

            var result = new LineState(null, cursorPosition);

            Assert.IsNull(result.Line);
            Assert.IsNull(result.LineBeforeCursor);
            Assert.IsNull(result.LineAfterCursor);
            Assert.AreEqual(0, result.CursorPosition);
        }

        [TestMethod]
        public void LineState_CursorPosition()
        {
            const string line = "Test";
            const int cursorPosition = 1;

            var result = new LineState(line, cursorPosition);

            Assert.AreEqual(line, result.Line);
            Assert.AreEqual("est", result.LineAfterCursor);
            Assert.AreEqual("T", result.LineBeforeCursor);
            Assert.AreEqual(cursorPosition, result.CursorPosition);
        }

        [TestMethod]
        public void LineState_CursorPositionBelowZero()
        {
            const string line = "Test";
            const int cursorPosition = -1;

            var result = new LineState(line, cursorPosition);

            Assert.AreEqual(line, result.Line);
            Assert.AreEqual(line, result.LineAfterCursor);
            Assert.AreEqual(string.Empty, result.LineBeforeCursor);
            Assert.AreEqual(0, result.CursorPosition);
        }

        [TestMethod]
        public void LineState_CursorPositionHigherThanLineLength()
        {
            const string line = "Test";
            const int cursorPosition = 6;

            var result = new LineState(line, cursorPosition);

            Assert.AreEqual(line, result.Line);
            Assert.AreEqual(string.Empty, result.LineAfterCursor);
            Assert.AreEqual(line, result.LineBeforeCursor);
            Assert.AreEqual(line.Length, result.CursorPosition);
        }
    }
}
