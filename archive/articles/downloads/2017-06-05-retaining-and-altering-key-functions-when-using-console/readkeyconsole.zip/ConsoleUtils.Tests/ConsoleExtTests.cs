﻿using System;
using ConsoleUtils.ConsoleActions;
using ConsoleUtils.Tests.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests
{
    [TestClass]
    public class ConsoleExtTests
    {
        [TestInitialize]
        public void Start()
        {
            ConsoleExt.ResetConsoleBehaviour();
            ConsoleExt.SetLine(string.Empty);
        }

        [TestMethod]
        public void ConsoleExt_SimulateKeyPress()
        {
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));

            Assert.AreEqual("a", ConsoleExt.LineState.Line);
            Assert.AreEqual(1, ConsoleExt.LineState.CursorPosition);
        }

        [TestMethod]
        public void ConsoleExt_SetLine()
        {
            const string anyLine = "This is a test";
            ConsoleExt.SetLine(anyLine);

            Assert.AreEqual(anyLine, ConsoleExt.LineState.Line);
            Assert.AreEqual(anyLine.Length, ConsoleExt.LineState.CursorPosition);
        }

        [TestMethod]
        public void ConsoleExt_ClearLine()
        {
            const string anyLine = "This is a test";
            ConsoleExt.SetLine(anyLine);

            Assert.AreEqual(anyLine, ConsoleExt.LineState.Line);
            Assert.AreEqual(anyLine.Length, ConsoleExt.LineState.CursorPosition);

            ConsoleExt.ClearLine();

            Assert.AreEqual(string.Empty, ConsoleExt.LineState.Line);
            Assert.AreEqual(0, ConsoleExt.LineState.CursorPosition);
        }

        [TestMethod]
        public void ConsoleExt_SetConsoleAction()
        {
            const string anyLine = "This is a test";
            ConsoleExt.SetLine(anyLine);

            ConsoleExt.SetConsoleAction(ConsoleModifiers.Control, ConsoleKey.A, new ClearLineAction());
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, true));

            Assert.AreEqual(anyLine, ConsoleExt.LineState.Line);
            
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, true));

            Assert.AreEqual(string.Empty, ConsoleExt.LineState.Line);
            Assert.AreEqual(0, ConsoleExt.LineState.CursorPosition);
        }

        [TestMethod]
        public void ConsoleExt_ResetConsoleBehaviour()
        {
            ConsoleExt.SetConsoleAction(0, ConsoleKey.A, new ClearLineAction());
            ConsoleExt.ResetConsoleBehaviour();
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));

            Assert.AreEqual("a", ConsoleExt.LineState.Line);
            Assert.AreEqual(1, ConsoleExt.LineState.CursorPosition);
        }

        [TestMethod]
        public void ConsoleExt_ConsoleAction_AllCombinations()
        {
            var consoleActionStub = new ConsoleActionStub();
            ConsoleExt.SetConsoleActionForAllModifierCombinations(ConsoleKey.A, consoleActionStub);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, true));

            Assert.AreEqual(8, consoleActionStub.CallCount);
        }

        [TestMethod]
        public void ConsoleExt_ConsoleAction_CtrlCombinations()
        {
            var consoleActionStub = new ConsoleActionStub();
            ConsoleExt.SetConsoleActionForCtrlModifierCombinations(ConsoleKey.A, consoleActionStub);
            
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, true));

            Assert.AreEqual(4, consoleActionStub.CallCount);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, false));

            Assert.AreEqual(4, consoleActionStub.CallCount);
        }

        [TestMethod]
        public void ConsoleExt_ConsoleAction_NonCtrlCombinations()
        {
            var consoleActionStub = new ConsoleActionStub();
            ConsoleExt.SetConsoleActionForNonCtrlModifierCombinations(ConsoleKey.A, consoleActionStub);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, false)); 

            Assert.AreEqual(4, consoleActionStub.CallCount);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, true));

            Assert.AreEqual(4, consoleActionStub.CallCount);
        }

        [TestMethod]
        public void ConsoleExt_ConsoleAction_CustomCombinations()
        {
            var consoleActionStub = new ConsoleActionStub();
            ConsoleExt.SetConsoleAction(ConsoleModifiers.Alt | ConsoleModifiers.Shift, ConsoleKey.A, consoleActionStub);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, false));

            Assert.AreEqual(1, consoleActionStub.CallCount);
            
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, true));

            Assert.AreEqual(1, consoleActionStub.CallCount);
        }

        [TestMethod]
        public void ConsoleExt_ConsoleAction_RemoveConsoleAction()
        {
            var consoleActionStub = new ConsoleActionStub();
            ConsoleExt.SetConsoleActionForAllModifierCombinations(ConsoleKey.A, consoleActionStub);
            ConsoleExt.RemoveConsoleAction(ConsoleModifiers.Alt | ConsoleModifiers.Shift, ConsoleKey.A);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, true));

            Assert.AreEqual(7, consoleActionStub.CallCount);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, false));

            Assert.AreEqual(7, consoleActionStub.CallCount);
        }

        [TestMethod]
        public void ConsoleExt_DefaultConsoleAction_AllCombinations()
        {
            var defaultConsoleActionStub = new ConsoleActionStub();
            ConsoleExt.SetDefaultConsoleActionForAllModifierCombinations(defaultConsoleActionStub);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, true));

            Assert.AreEqual(8, defaultConsoleActionStub.CallCount);

            var consoleActionStub = new ConsoleActionStub();
            ConsoleExt.SetConsoleActionForNonCtrlModifierCombinations(ConsoleKey.A, consoleActionStub);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, false));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, false));

            Assert.AreEqual(4, consoleActionStub.CallCount);
            Assert.AreEqual(8, defaultConsoleActionStub.CallCount);

            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, false, true, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, false, true));
            ConsoleExt.SimulateKeyPress(new ConsoleKeyInfo('a', ConsoleKey.A, true, true, true));

            Assert.AreEqual(4, consoleActionStub.CallCount);
            Assert.AreEqual(12, defaultConsoleActionStub.CallCount);
        }
    }
}
