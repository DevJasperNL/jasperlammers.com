﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests
{
    [TestClass]
    public class PreviousLineBufferTests
    {
        [TestMethod]
        public void PreviousLineBuffer_Constructed()
        {
            var buffer = new PreviousLineBuffer();

            Assert.IsNotNull(buffer.PreviousLines);
            Assert.AreEqual(0, buffer.PreviousLines.Count);
            Assert.IsFalse(buffer.HasLines);
            Assert.AreEqual(0, buffer.Index);
            Assert.IsNull(buffer.LastLine);
            Assert.IsNull(buffer.LineAtIndex);
        }

        [TestMethod]
        public void PreviousLineBuffer_AddLine()
        {
            var buffer = new PreviousLineBuffer();

            const string someLine = "Line of text";
            buffer.AddLine(someLine);
            
            Assert.AreEqual(1, buffer.PreviousLines.Count);
            Assert.IsTrue(buffer.HasLines);
            Assert.AreEqual(0, buffer.Index);
            Assert.AreEqual(someLine, buffer.LastLine);
            Assert.AreEqual(someLine, buffer.LineAtIndex);
        }

        [TestMethod]
        public void PreviousLineBuffer_AddTwoLines()
        {
            var buffer = new PreviousLineBuffer();

            const string someLine = "Line of text";
            buffer.AddLine(someLine);

            const string someOtherLine = "Other line of text";
            buffer.AddLine(someOtherLine);

            Assert.AreEqual(2, buffer.PreviousLines.Count);
            Assert.AreEqual(1, buffer.Index);
            Assert.AreEqual(someOtherLine, buffer.LastLine);
            Assert.AreEqual(someOtherLine, buffer.LineAtIndex);
        }

        [TestMethod]
        public void PreviousLineBuffer_CycleUp_FirstTimeNoCycling()
        {
            var buffer = new PreviousLineBuffer();

            List<string> lines = new List<string>
            {
                "line 1",
                "line 2",
                "line 3",
                "line 4",
            };
            
            foreach (string line in lines)
            {
                buffer.AddLine(line);
            }

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);

            buffer.CycleUp();

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);
        }

        [TestMethod]
        public void PreviousLineBuffer_CycleUp()
        {
            var buffer = new PreviousLineBuffer();

            List<string> lines = new List<string>
            {
                "line 1",
                "line 2",
                "line 3",
                "line 4",
            };
            
            foreach (string line in lines)
            {
                buffer.AddLine(line);
            }

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);

            buffer.CycleUp();
            for (int i = lines.Count - 1; i > 0; i--)
            {
                buffer.CycleUp();

                Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
                Assert.AreEqual(i - 1, buffer.Index);
                Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
                Assert.AreEqual(lines[i - 1], buffer.LineAtIndex);
            }

            for (int i = 0; i < 2; i++)
            {
                buffer.CycleUp();

                Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
                Assert.AreEqual(0, buffer.Index);
                Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
                Assert.AreEqual(lines[0], buffer.LineAtIndex);
            }
        }

        [TestMethod]
        public void PreviousLineBuffer_CycleUpAndAround_FirstTimeNoCycling()
        {
            var buffer = new PreviousLineBuffer();

            List<string> lines = new List<string>
            {
                "line 1",
                "line 2",
                "line 3",
                "line 4",
            };

            foreach (string line in lines)
            {
                buffer.AddLine(line);
            }

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);

            buffer.CycleUpAndAround();

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);
        }

        [TestMethod]
        public void PreviousLineBuffer_CycleUpAndAround()
        {
            var buffer = new PreviousLineBuffer();

            List<string> lines = new List<string>
            {
                "line 1",
                "line 2",
                "line 3",
                "line 4",
            };
            
            foreach (string line in lines)
            {
                buffer.AddLine(line);
            }

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);

            buffer.CycleUpAndAround();
            for (int i = lines.Count - 1; i > 0; i--)
            {
                buffer.CycleUpAndAround();

                Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
                Assert.AreEqual(i - 1, buffer.Index);
                Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
                Assert.AreEqual(lines[i - 1], buffer.LineAtIndex);
            }

            for (int j = 0; j < 2; j++)
            {
                for (int i = lines.Count; i > 0; i--)
                {
                    buffer.CycleUpAndAround();

                    Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
                    Assert.AreEqual(i - 1, buffer.Index);
                    Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
                    Assert.AreEqual(lines[i - 1], buffer.LineAtIndex);
                }
            }
        }

        [TestMethod]
        public void PreviousLineBuffer_CycleTop()
        {
            var buffer = new PreviousLineBuffer();

            List<string> lines = new List<string>
            {
                "line 1",
                "line 2",
                "line 3",
                "line 4",
            };


            foreach (string line in lines)
            {
                buffer.AddLine(line);
            }

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);

            buffer.CycleTop();
            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(0, buffer.Index);
            Assert.AreEqual(lines[0], buffer.LineAtIndex);
        }

        [TestMethod]
        public void PreviousLineBuffer_CycleBottom()
        {
            var buffer = new PreviousLineBuffer();

            List<string> lines = new List<string>
            {
                "line 1",
                "line 2",
                "line 3",
                "line 4",
            };
            
            foreach (string line in lines)
            {
                buffer.AddLine(line);
            }

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);

            buffer.CycleTop();
            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(0, buffer.Index);
            Assert.AreEqual(lines[0], buffer.LineAtIndex);

            buffer.CycleBottom();
            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);
        }

        [TestMethod]
        public void PreviousLineBuffer_CycleDown()
        {
            var buffer = new PreviousLineBuffer();

            List<string> lines = new List<string>
            {
                "line 1",
                "line 2",
                "line 3",
                "line 4",
            };
            
            foreach (string line in lines)
            {
                buffer.AddLine(line);
            }

            Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
            Assert.AreEqual(lines.Count - 1, buffer.Index);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LastLine);
            Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);

            buffer.CycleTop();
            for (int i = 0; i < lines.Count - 1; i++)
            {
                buffer.CycleDown();

                Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
                Assert.AreEqual(i + 1, buffer.Index);
                Assert.AreEqual(lines[i + 1], buffer.LineAtIndex);
            }

            for (int i = 0; i < 2; i++)
            {
                buffer.CycleDown();

                Assert.AreEqual(lines.Count, buffer.PreviousLines.Count);
                Assert.AreEqual(lines.Count - 1, buffer.Index);
                Assert.AreEqual(lines[lines.Count - 1], buffer.LineAtIndex);
            }
        }
    }
}
