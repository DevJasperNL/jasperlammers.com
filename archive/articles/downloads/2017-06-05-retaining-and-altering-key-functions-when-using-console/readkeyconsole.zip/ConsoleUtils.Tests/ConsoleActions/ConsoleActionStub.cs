﻿using System;
using ConsoleUtils.ConsoleActions;

namespace ConsoleUtils.Tests.ConsoleActions
{
    public class ConsoleActionStub : IConsoleAction
    {
        public void Execute(IConsole console, ConsoleKeyInfo consoleKeyInfo)
        {
            CallCount++;
        }

        public int CallCount { get; private set; }
    }
}
