﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class AutoCompleteUsingPreviousLinesActionTests
    {
        [TestMethod]
        public void AutoCompleteUsingPreviousLinesAction_AutoComplete()
        {
            AutoCompleteUsingPreviousLinesAction action = new AutoCompleteUsingPreviousLinesAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("SomeThing");
            console.PreviousLineBuffer.AddLine("So, this is a test");
            console.PreviousLineBuffer.AddLine("Test");

            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("So, this is a test", console.CurrentLine);
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeThing", console.CurrentLine);
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("So, this is a test", console.CurrentLine);
        }
    }
}
