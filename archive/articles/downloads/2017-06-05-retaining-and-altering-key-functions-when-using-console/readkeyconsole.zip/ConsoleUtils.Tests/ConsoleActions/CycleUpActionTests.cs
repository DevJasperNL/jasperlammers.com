﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class CycleUpActionTests
    {
        [TestMethod]
        public void CycleUpAction_AutoComplete()
        {
            CycleUpAction action = new CycleUpAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("Line1");
            console.PreviousLineBuffer.AddLine("Line2");
            console.PreviousLineBuffer.AddLine("Line3");
            
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("Line3", console.CurrentLine);
            Assert.AreEqual(5, console.CursorPosition);
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("Line2", console.CurrentLine);
            Assert.AreEqual(5, console.CursorPosition);
        }
    }
}
