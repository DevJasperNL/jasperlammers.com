﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class InsertStringActionTests
    {
        [TestMethod]
        public void InsertStringAction_InsertString()
        {
            InsertStringAction action = new InsertStringAction("NewString");
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SoNewStringmeLine", console.CurrentLine);
        }
    }
}
