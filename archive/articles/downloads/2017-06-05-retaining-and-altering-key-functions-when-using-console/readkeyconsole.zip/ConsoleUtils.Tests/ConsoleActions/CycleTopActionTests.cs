﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class CycleTopActionTests
    {
        [TestMethod]
        public void CycleTopAction_AutoComplete()
        {
            CycleTopAction action = new CycleTopAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("Line1");
            console.PreviousLineBuffer.AddLine("Line2");
            console.PreviousLineBuffer.AddLine("Line3");
            
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("Line1", console.CurrentLine);
            Assert.AreEqual(5, console.CursorPosition);
        }
    }
}
