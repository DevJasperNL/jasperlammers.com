﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class AutoCompleteSingleCharacterActionTests
    {
        [TestMethod]
        public void AutoCompleteSingleCharacterAction_AutoCompleteDoesntOverwriteLine()
        {
            AutoCompleteSingleCharacterAction action = new AutoCompleteSingleCharacterAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 6,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("This is a test");

            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeLine", console.CurrentLine);
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeLine", console.CurrentLine);
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeLinea", console.CurrentLine);
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeLinea ", console.CurrentLine);
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeLinea t", console.CurrentLine);
        }

        [TestMethod]
        public void AutoCompleteSingleCharacterAction_UnableToAutoComplete_NoPreviousEntry()
        {
            AutoCompleteSingleCharacterAction action = new AutoCompleteSingleCharacterAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 6,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeLine", console.CurrentLine);
        }

        [TestMethod]
        public void AutoCompleteSingleCharacterAction_UnableToAutoComplete_PastPreviousEntryLength()
        {
            AutoCompleteSingleCharacterAction action = new AutoCompleteSingleCharacterAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 8,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("Test");

            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeLine", console.CurrentLine);
        }
    }
}
