﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class MoveCursorLeftActionTests
    {
        [TestMethod]
        public void MoveCursorLeftAction_MoveLeft()
        {
            MoveCursorLeftAction action = new MoveCursorLeftAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
            Assert.AreEqual(1, console.CursorPosition);
        }

        [TestMethod]
        public void MoveCursorLeftAction_MoveLeft_FirstIndex()
        {
            MoveCursorLeftAction action = new MoveCursorLeftAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 0,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
            Assert.AreEqual(0, console.CursorPosition);
        }
    }
}
