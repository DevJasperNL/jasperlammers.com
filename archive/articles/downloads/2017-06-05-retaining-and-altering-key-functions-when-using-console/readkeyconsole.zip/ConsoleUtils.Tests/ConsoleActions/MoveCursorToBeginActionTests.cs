﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class MoveCursorToBeginActionTests
    {
        [TestMethod]
        public void MoveCursorToBeginAction()
        {
            MoveCursorToBeginAction action = new MoveCursorToBeginAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
            Assert.AreEqual(0, console.CursorPosition);
        }
    }
}
