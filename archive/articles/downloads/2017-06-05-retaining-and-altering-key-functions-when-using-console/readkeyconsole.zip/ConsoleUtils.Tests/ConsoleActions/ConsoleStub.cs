﻿using ConsoleUtils.ConsoleActions;

namespace ConsoleUtils.Tests.ConsoleActions
{
    class ConsoleStub : IConsole
    {
        public ConsoleStub()
        {
            PreviousLineBuffer = new PreviousLineBuffer();
        }

        public PreviousLineBuffer PreviousLineBuffer { get; }
        public string CurrentLine { get; set; }
        public int CursorPosition { get; set; }
    }
}
