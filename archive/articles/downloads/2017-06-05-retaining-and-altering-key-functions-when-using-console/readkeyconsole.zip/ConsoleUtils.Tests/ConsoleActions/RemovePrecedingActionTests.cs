﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class RemovePrecedingActionTests
    {
        [TestMethod]
        public void RemovePrecedingAction_RemovePreceding()
        {
            RemovePrecedingAction action = new RemovePrecedingAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("meLine", console.CurrentLine);
        }

        [TestMethod]
        public void RemovePrecedingAction_RemovePreceding_FirstIndex()
        {
            RemovePrecedingAction action = new RemovePrecedingAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 0,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
        }
    }
}
