﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class BackspaceActionTests
    {
        [TestMethod]
        public void BackspaceAction_RemoveCharacter()
        {
            BackspaceAction action = new BackspaceAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SmeLine", console.CurrentLine);
        }

        [TestMethod]
        public void BackspaceAction_RemoveCharacter_FirstIndex()
        {
            BackspaceAction action = new BackspaceAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 0,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
        }
    }
}
