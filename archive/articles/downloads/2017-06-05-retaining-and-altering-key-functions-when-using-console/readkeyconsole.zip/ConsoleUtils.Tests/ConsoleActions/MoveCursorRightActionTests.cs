﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class MoveCursorRightActionTests
    {
        [TestMethod]
        public void MoveCursorRightAction_MoveRight()
        {
            MoveCursorRightAction action = new MoveCursorRightAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
            Assert.AreEqual(3, console.CursorPosition);
        }

        [TestMethod]
        public void MoveCursorRightAction_MoveRight_LastIndex()
        {
            MoveCursorRightAction action = new MoveCursorRightAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 8,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
            Assert.AreEqual(8, console.CursorPosition);
        }
    }
}
