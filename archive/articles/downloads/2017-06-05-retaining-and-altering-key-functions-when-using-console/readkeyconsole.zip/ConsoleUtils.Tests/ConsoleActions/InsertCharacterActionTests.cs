﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class InsertCharacterActionTests
    {
        [TestMethod]
        public void InsertCharacterAction_InsertCharacter()
        {
            InsertCharacterAction action = new InsertCharacterAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo('a', ConsoleKey.A, false, false, false));

            Assert.AreEqual("SoameLine", console.CurrentLine);
        }
    }
}
