﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class MoveCursorToEndActionTests
    {
        [TestMethod]
        public void MoveCursorToEndAction()
        {
            MoveCursorToEndAction action = new MoveCursorToEndAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
            Assert.AreEqual(8, console.CursorPosition);
        }
    }
}
