﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class DeleteActionTests
    {
        [TestMethod]
        public void DeleteAction_DeleteCharacter()
        {
            DeleteAction action = new DeleteAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SoeLine", console.CurrentLine);
        }

        [TestMethod]
        public void DeleteAction_DeleteCharacter_LastIndex()
        {
            DeleteAction action = new DeleteAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 8,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
        }
    }
}
