﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class ClearLineActionTests
    {
        [TestMethod]
        public void ClearLineAction()
        {
            ClearLineAction action = new ClearLineAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual(string.Empty, console.CurrentLine);
            Assert.AreEqual(0, console.CursorPosition);
        }
    }
}
