﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class RemoveSucceedingActionTests
    {
        [TestMethod]
        public void RemoveSucceedingAction_RemoveSucceeding()
        {
            RemoveSucceedingAction action = new RemoveSucceedingAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("So", console.CurrentLine);
        }

        [TestMethod]
        public void RemoveSucceedingAction_RemoveSucceeding_LastIndex()
        {
            RemoveSucceedingAction action = new RemoveSucceedingAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 8,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
        }
    }
}
