﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class CycleBottomActionTests
    {
        [TestMethod]
        public void CycleBottomAction_InitiallyNoAction()
        {
            CycleBottomAction action = new CycleBottomAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("Line1");
            console.PreviousLineBuffer.AddLine("Line2");
            console.PreviousLineBuffer.AddLine("Line3");

            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("SomeLine", console.CurrentLine);
            Assert.AreEqual(2, console.CursorPosition);
        }

        [TestMethod]
        public void CycleBottomAction_AutoComplete()
        {
            CycleBottomAction action = new CycleBottomAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("Line1");
            console.PreviousLineBuffer.AddLine("Line2");
            console.PreviousLineBuffer.AddLine("Line3");

            console.PreviousLineBuffer.CycleTop();
            
            action.Execute(console, new ConsoleKeyInfo());
            Assert.AreEqual("Line3", console.CurrentLine);
            Assert.AreEqual(5, console.CursorPosition);
        }
    }
}
