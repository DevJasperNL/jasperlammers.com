﻿using System;
using ConsoleUtils.ConsoleActions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConsoleUtils.Tests.ConsoleActions
{
    [TestClass]
    public class AutoCompleteRestOfLineActionTests
    {
        [TestMethod]
        public void AutoCompleteRestOfLineAction_AutoComplete()
        {
            AutoCompleteRestOfLineAction action = new AutoCompleteRestOfLineAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("This is a test");

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("Sois is a test", console.CurrentLine);
        }

        [TestMethod]
        public void AutoCompleteRestOfLineAction_UnableToAutoComplete_NoPreviousEntry()
        {
            AutoCompleteRestOfLineAction action = new AutoCompleteRestOfLineAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 2,
                CurrentLine = "SomeLine"
            };

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
        }

        [TestMethod]
        public void AutoCompleteRestOfLineAction_UnableToAutoComplete_PastPreviousEntryLength()
        {
            AutoCompleteRestOfLineAction action = new AutoCompleteRestOfLineAction();
            ConsoleStub console = new ConsoleStub
            {
                CursorPosition = 5,
                CurrentLine = "SomeLine"
            };
            console.PreviousLineBuffer.AddLine("Test");

            action.Execute(console, new ConsoleKeyInfo());

            Assert.AreEqual("SomeLine", console.CurrentLine);
        }
    }
}
