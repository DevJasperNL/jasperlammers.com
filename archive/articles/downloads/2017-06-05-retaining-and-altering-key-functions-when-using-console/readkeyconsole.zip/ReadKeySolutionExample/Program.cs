﻿using System;
using ConsoleUtils;

namespace ReadKeySolutionExample
{
    class Program
    {
        static void Main(string[] args)
        {
            bool running = true;
            while (running)
            {
                var result = ConsoleExt.ReadKey();
                if (result.Key == ConsoleKey.Enter && result.LineBeforeKeyPress.Line.ToLower() == "exit")
                    running = false;
            }
        }
    }
}
