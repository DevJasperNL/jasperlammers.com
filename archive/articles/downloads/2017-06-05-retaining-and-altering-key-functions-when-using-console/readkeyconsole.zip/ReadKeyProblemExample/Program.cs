﻿using System;

namespace ReadKeyProblemExample
{
    class Program
    {
        static void Main(string[] args)
        {
            bool running = true;
            string line = string.Empty;
            while (running)
            {
                var key = Console.ReadKey();
                if (key.Key == ConsoleKey.Enter)
                {
                    if (line.ToLower() == "exit")
                        running = false;
                    Console.WriteLine(line);
                    line = string.Empty;
                }
                else
                    line += key.KeyChar;
            }
        }
    }
}
