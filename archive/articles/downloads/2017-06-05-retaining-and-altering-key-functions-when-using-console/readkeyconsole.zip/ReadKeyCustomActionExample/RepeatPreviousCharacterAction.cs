﻿using System;
using ConsoleUtils.ConsoleActions;

namespace ReadKeyCustomActionExample
{
    public class RepeatPreviousCharacterAction : IConsoleAction
    {
        public void Execute(IConsole console, ConsoleKeyInfo consoleKeyInfo)
        {
            if (console.CursorPosition <= 0)
                return;
            var previousChar = console.CurrentLine[console.CursorPosition - 1].ToString();
            console.CurrentLine = console.CurrentLine.Insert(console.CursorPosition, previousChar);
            console.CursorPosition += 1;
        }
    }
}
