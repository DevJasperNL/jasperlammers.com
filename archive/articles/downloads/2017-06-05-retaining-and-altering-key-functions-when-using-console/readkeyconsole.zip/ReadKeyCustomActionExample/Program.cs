﻿using System;
using ConsoleUtils;

namespace ReadKeyCustomActionExample
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleExt.SetConsoleActionForNonCtrlModifierCombinations(ConsoleKey.Tab, new RepeatPreviousCharacterAction());

            bool running = true;
            while (running)
            {
                var result = ConsoleExt.ReadKey();
                if (result.Key == ConsoleKey.Enter && result.LineBeforeKeyPress.Line.ToLower() == "exit")
                    running = false;
            }
        }
    }
}
