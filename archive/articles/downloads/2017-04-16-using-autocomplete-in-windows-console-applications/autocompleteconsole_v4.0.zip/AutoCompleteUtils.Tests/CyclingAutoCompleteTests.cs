﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AutoCompleteUtils.Tests
{
    [TestClass]
    public class CyclingAutoCompleteTests
    {
        [TestMethod]
        public void AutoComplete_NullLineReturnsLine()
        {
            var cac = new CyclingAutoComplete();

            var anyStrings = new List<string>();
            var result = cac.AutoComplete(null, anyStrings);

            Assert.AreEqual((object) null, result);
        }

        [TestMethod]
        public void AutoComplete_EmptyLineReturnsLine()
        {
            var cac = new CyclingAutoComplete();

            var anyStrings = new List<string>();
            var result = cac.AutoComplete(string.Empty, anyStrings);

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void AutoComplete_NullStringsReturnsLine()
        {
            var cac = new CyclingAutoComplete();

            const string anyLine = "Line";
            var result = cac.AutoComplete(anyLine, null);

            Assert.AreEqual(anyLine, result);
        }

        [TestMethod]
        public void AutoComplete_EmptyStringsReturnsLine()
        {
            var cac = new CyclingAutoComplete();

            const string anyLine = "Line";
            var result = cac.AutoComplete(anyLine, new List<string>());

            Assert.AreEqual(anyLine, result);
        }

        [TestMethod]
        public void AutoComplete_SingleResult_IgnoreCase()
        {
            var cac = new CyclingAutoComplete();
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
                "HalLo Blue world",
            };

            var result = cac.AutoComplete("Hallo", strings);
            Assert.AreEqual(strings[3], result);
            result = cac.AutoComplete(result, strings);
            Assert.AreEqual(strings[3], result);
        }

        [TestMethod]
        public void AutoComplete_SingleResult_DontIgnoreCase()
        {
            var cac = new CyclingAutoComplete();
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
                "HalLo Blue world",
            };

            var result = cac.AutoComplete("hello", strings, false);
            Assert.AreEqual(strings[1], result);
            result = cac.AutoComplete(result, strings, false);
            Assert.AreEqual(strings[1], result);
        }

        [TestMethod]
        public void AutoComplete_CyclingResult_IgnoreCase()
        {
            var cac = new CyclingAutoComplete();
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
                "Hallo Blue world",
            };

            var result = cac.AutoComplete("Hello", strings);
            Assert.AreEqual(strings[0], result);
            result = cac.AutoComplete(result, strings);
            Assert.AreEqual(strings[1], result);
            result = cac.AutoComplete(result, strings);
            Assert.AreEqual(strings[2], result);
            result = cac.AutoComplete(result, strings);
            Assert.AreEqual(strings[0], result);
        }

        [TestMethod]
        public void AutoComplete_CyclingForwardAndBackward()
        {
            var cac = new CyclingAutoComplete();
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
                "Hallo Blue world",
            };

            var result = cac.AutoComplete("Hello", strings);
            Assert.AreEqual(strings[0], result);
            result = cac.AutoComplete(result, strings);
            Assert.AreEqual(strings[1], result);
            result = cac.AutoComplete(result, strings, CyclingDirections.Backward);
            Assert.AreEqual(strings[0], result);
            result = cac.AutoComplete(result, strings, CyclingDirections.Backward);
            Assert.AreEqual(strings[2], result);
        }

        [TestMethod]
        public void AutoComplete_CyclingResult_DontIgnoreCase()
        {
            var cac = new CyclingAutoComplete();
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
                "Hallo Blue world",
            };

            var result = cac.AutoComplete("Hello", strings, false);
            Assert.AreEqual(strings[0], result);
            result = cac.AutoComplete(result, strings, false);
            Assert.AreEqual(strings[2], result);
            result = cac.AutoComplete(result, strings, false);
            Assert.AreEqual(strings[0], result);
        }

        [TestMethod]
        public void AutoComplete_CyclingResult_NewCycle()
        {
            var cac = new CyclingAutoComplete();
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
                "Hallo Blue world",
            };

            var result = cac.AutoComplete("Hello", strings);
            Assert.AreEqual(strings[0], result);
            result = cac.AutoComplete(result, strings);
            Assert.AreEqual(strings[1], result);
            result = cac.AutoComplete("Hello", strings);
            Assert.AreEqual(strings[0], result);
            result = cac.AutoComplete(result, strings);
            Assert.AreEqual(strings[1], result);
        }
    }
}
