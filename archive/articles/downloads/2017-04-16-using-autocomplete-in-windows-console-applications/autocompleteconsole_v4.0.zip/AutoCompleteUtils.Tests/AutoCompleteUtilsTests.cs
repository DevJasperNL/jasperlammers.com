﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AutoCompleteUtils.Tests
{
    [TestClass]
    public class AutoCompleteUtilsTests
    {
        [TestMethod]
        public void GetAutoCompletePossibilities_NullReturnsEmptyList()
        {
            var anyStrings = new List<string>();
            var result = AutoComplete.GetAutoCompletePossibilities(null, anyStrings);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void GetAutoCompletePossibilities_EmptyStringReturnsEmptyList()
        {
            var anyStrings = new List<string>();
            var result = AutoComplete.GetAutoCompletePossibilities(string.Empty, anyStrings);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void GetAutoCompletePossibilities_NullStringsReturnsEmptyList()
        {
            const string anyInput = "Hello World";
            var result = AutoComplete.GetAutoCompletePossibilities(anyInput, null);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void GetAutoCompletePossibilities_EmptyStringsReturnsEmptyList()
        {
            const string anyInput = "Hello World";
            var result = AutoComplete.GetAutoCompletePossibilities(anyInput, new List<string>());

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void GetAutoCompletePossibilities_IgnoreCase()
        {
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hallo Blue world",
            };

            var result = AutoComplete.GetAutoCompletePossibilities("hEllo", strings);

            var expectedResults = new List<string>
            {
                "Hello green world",
                "hello Blue world",
            };
            Assert.IsNotNull(result);
            CollectionAssert.AreEquivalent(expectedResults, result);
        }

        [TestMethod]
        public void GetAutoCompletePossibilities_DontIgnoreCase()
        {
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hallo Blue world",
            };

            var result = AutoComplete.GetAutoCompletePossibilities("hello", strings, false);

            var expectedResults = new List<string>()
            {
                "hello Blue world",
            };
            Assert.IsNotNull(result);
            CollectionAssert.AreEquivalent(expectedResults, result);
        }

        [TestMethod]
        public void GetEqualLeadingString_NullStringsReturnsEmptyString()
        {
            var result = AutoComplete.GetEqualLeadingString(null);
            
            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void GetEqualLeadingString_EmptyStringsReturnsEmptyString()
        {
            var result = AutoComplete.GetEqualLeadingString(new List<string>());

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void GetEqualLeadingString_SingleStringReturnsString()
        {
            var strings = new List<string>
            {
                "Hello green world"
            };
            var result = AutoComplete.GetEqualLeadingString(strings);

            Assert.AreEqual(strings[0], result);
        }

        [TestMethod]
        public void GetEqualLeadingString_IgnoreCase()
        {
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
            };
            var result = AutoComplete.GetEqualLeadingString(strings);

            Assert.AreEqual("Hello ", result, true);
        }

        [TestMethod]
        public void GetEqualLeadingString_DontIgnoreCase()
        {
            var strings = new List<string>
            {
                "Hello BlUe world",
                "Hello Blue world",
            };
            var result = AutoComplete.GetEqualLeadingString(strings, false);

            Assert.AreEqual("Hello Bl", result, false);
        }

        [TestMethod]
        public void GetComplimentaryAutoComplete_NullInputReturnsInput()
        {
            var anyStrings = new List<string>();
            var result = AutoComplete.GetComplimentaryAutoComplete(null, anyStrings);

            Assert.AreEqual(null, result);
        }

        [TestMethod]
        public void GetComplimentaryAutoComplete_EmptyInputReturnsInput()
        {
            var anyStrings = new List<string>();
            var result = AutoComplete.GetComplimentaryAutoComplete(string.Empty, anyStrings);

            Assert.AreEqual(string.Empty, result);
        }

        [TestMethod]
        public void GetComplimentaryAutoComplete_NullStringsReturnsInput()
        {
            const string anyInput = "Input";
            var result = AutoComplete.GetComplimentaryAutoComplete(anyInput, null);

            Assert.AreEqual(anyInput, result);
        }

        [TestMethod]
        public void GetComplimentaryAutoComplete_EmptyStringsReturnsInput()
        {
            const string anyInput = "Input";
            var result = AutoComplete.GetComplimentaryAutoComplete(anyInput, new List<string>());

            Assert.AreEqual(anyInput, result);
        }

        [TestMethod]
        public void GetComplimentaryAutoComplete_NoPossibilitiesReturnsInput()
        {
            var strings = new List<string>
            {
                "Hello green world",
            };
            const string notMatchingInput = "B";
            var result = AutoComplete.GetComplimentaryAutoComplete(notMatchingInput, strings);

            Assert.AreEqual(notMatchingInput, result);
        }

        [TestMethod]
        public void GetComplimentaryAutoComplete_NoAutoCompleteReturnsInput()
        {
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
                "Hallo Blue world",
            };
            const string input = "h";
            var result = AutoComplete.GetComplimentaryAutoComplete(input, strings);

            Assert.AreEqual(input, result);
        }

        [TestMethod]
        public void GetComplimentaryAutoComplete_IgnoreCase()
        {
            var strings = new List<string>
            {
                "Hello green world",
                "hello Blue world",
                "Hello Blue world",
                "Hallo Blue world",
            };
            var result = AutoComplete.GetComplimentaryAutoComplete("hE", strings);

            Assert.AreEqual("hello ", result, true);
        }

        [TestMethod]
        public void GetComplimentaryAutoComplete_DontIgnoreCase()
        {
            var strings = new List<string>
            {
                "Hello BlUe world",
                "hello Blue world",
                "Hello Blue world",
                "Hallo Blue world",
            };
            var result = AutoComplete.GetComplimentaryAutoComplete("He", strings, false);

            Assert.AreEqual("Hello Bl", result, false);
        }
    }
}
