﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoCompleteUtils;
using ConsoleUtils;

namespace ComplimentaryAutoCompleteExample
{
    class Program
    {
        private static void Main(string[] args)
        {
            var commands = new List<string>
            {
                "Exit",
                "The green ball.",
                "The red ball.",
                "The red block.",
                "The round ball."
            };

            var running = true;
            while (running)
            {
                var result = ConsoleExt.ReadKey();
                switch (result.Key)
                {
                    case ConsoleKey.Enter:
                        var lowerLine = result.LineBeforeKeyPress.Line.ToLower();
                        if (lowerLine == "exit")
                            running = false;
                        else if (commands.Any(c => c.ToLower() == lowerLine))
                            Console.WriteLine("Command recognised!");
                        break;
                    case ConsoleKey.Tab:
                        string autoCompletedLine =
                            AutoComplete.GetComplimentaryAutoComplete(result.LineBeforeKeyPress.LineBeforeCursor,
                                commands);
                        ConsoleExt.SetLine(autoCompletedLine);
                        break;
                }
            }
        }
    }
}
