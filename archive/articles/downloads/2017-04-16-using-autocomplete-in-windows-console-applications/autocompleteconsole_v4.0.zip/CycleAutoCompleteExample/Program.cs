﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoCompleteUtils;
using ConsoleUtils;

namespace CycleAutoCompleteExample
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var commands = new List<string>
            {
                "Exit",
                "The green ball.",
                "The red ball.",
                "The red block.",
                "The round ball."
            };

            var running = true;
            var cyclingAutoComplete = new CyclingAutoComplete();
            while (running)
            {
                var result = ConsoleExt.ReadKey();
                switch (result.Key)
                {
                    case ConsoleKey.Enter:
                        var lowerLine = result.LineBeforeKeyPress.Line.ToLower();
                        if (lowerLine == "exit")
                            running = false;
                        else if (commands.Any(c => c.ToLower() == lowerLine))
                            Console.WriteLine("Command recognised!");
                        break;
                    case ConsoleKey.Tab:
                        var shiftPressed = (result.Modifiers & ConsoleModifiers.Shift) != 0;
                        var cyclingDirection = shiftPressed ? CyclingDirections.Backward : CyclingDirections.Forward;
                        var autoCompletedLine =
                            cyclingAutoComplete.AutoComplete(result.LineBeforeKeyPress.LineBeforeCursor,
                                commands, cyclingDirection);
                        ConsoleExt.SetLine(autoCompletedLine);
                        break;
                }
            }
        }
    }
}
