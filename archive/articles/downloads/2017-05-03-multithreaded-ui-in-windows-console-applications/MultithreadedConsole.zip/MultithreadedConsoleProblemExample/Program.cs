﻿using System;
using System.Threading;

namespace MultithreadedConsoleProblemExample
{
    class Program
    {
        private static bool _running = true;

        static void Main(string[] args)
        {
            Thread eventThread = new Thread(ThreadMethod);
            eventThread.Start();

            while (_running)
            {
                var line = Console.ReadLine();
                if (line != null && line.ToLower() == "exit")
                    _running = false;
            }
        }

        static void ThreadMethod()
        {
            while (_running)
            {
                for (int i = 0; i < 40; i++)
                {
                    if (!_running)
                        return;
                    Thread.Sleep(100);
                }
                Console.WriteLine("This is an event on a different thread!");
            }
        }
    }
}
