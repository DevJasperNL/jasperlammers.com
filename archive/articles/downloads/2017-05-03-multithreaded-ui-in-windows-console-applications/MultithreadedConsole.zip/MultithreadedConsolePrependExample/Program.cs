﻿using System;
using System.Threading;
using ConsoleUtils;

namespace MultithreadedConsolePrependExample
{
    public class Program
    {
        private static bool _running = true;

        static void Main(string[] args)
        {
            Thread eventThread = new Thread(ThreadMethod);
            eventThread.Start();
            while (_running)
            {
                var line = ConsoleExt.ReadLine();
                if (line.ToLower() == "exit")
                    _running = false;
            }
        }

        static void ThreadMethod()
        {
            while (_running)
            {
                for (int i = 0; i < 40; i++)
                {
                    if (!_running)
                        return;
                    Thread.Sleep(100);
                }
                ConsoleExt.PrependLine("This is an event on a different thread!");
            }
        }
    }
}
